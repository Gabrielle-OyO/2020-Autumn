#include"3-4.h"

int main()
{
	int n,t;
	int sum=0;
	cout << "ÇëÊäÈëÒ»¸öÐ¡ÓÚ10µÄn£º" << endl;
	cin >> n;
	factorial A(n);
	cout << A.f(n);
}