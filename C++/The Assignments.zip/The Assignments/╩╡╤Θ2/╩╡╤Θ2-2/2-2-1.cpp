inline int f1(int x, int y)

{
	return x + y;
}