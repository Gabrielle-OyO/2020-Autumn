inline int f4(int x4, int y4)

{
	return x4 / y4;
}