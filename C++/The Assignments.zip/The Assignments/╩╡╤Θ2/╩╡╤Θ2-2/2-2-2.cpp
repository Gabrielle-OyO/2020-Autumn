inline int f2(int x2, int y2)

{
	return x2 - y2;
}