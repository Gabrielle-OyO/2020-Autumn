inline int f3(int x3, int y3)

{
	return x3 * y3;
}