#include <iostream>
using namespace std;
#include "2-2-1.cpp"
#include "2-2-2.cpp"
#include "2-2-3.cpp"
#include "2-2-4.cpp"
#pragma once
