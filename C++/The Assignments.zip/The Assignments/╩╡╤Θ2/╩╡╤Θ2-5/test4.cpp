#include "test4.h"

int main()
{
	int a, b;
	cin >> a >> b;

	shit A(a, b);
	A.print();

	return 0;
}